/*****                      Graphics.h                  *****/
//--- YT Graphs -------------------------------------------------------------
extern char HeaderYT[80];
int NoOfGraphs = 1;
int YTValues   = 0;
int MatValues  = 0;

//--- YT Graphs -------------------------------------------------------------
char Sig1[20],Sig2[20],Sig3[20],Sig4[20],
     Sig5[20],Sig6[20],Sig7[20],Sig8[20],
     Sig9[20],Sig10[20],Sig11[20],Sig12[20],
     Sig13[20],Sig14[20],Sig15[20],Sig16[20],
     Sig17[20],Sig18[20],Sig19[20],Sig20[20],
     Sig21[20],Sig22[20],Sig23[20],Sig24[20],
     Sig25[20],Sig26[20],Sig27[20];

//--- YT Graphs -------------------------------------------------------------
float ampl1  = 0.0,ampl2  = 0.0,ampl3  = 0.0,ampl4  = 0.0,
      ampl5  = 0.0,ampl6  = 0.0,ampl7  = 0.0,ampl8  = 0.0,
      ampl9  = 0.0,ampl10 = 0.0,ampl11 = 0.0,ampl12 = 0.0,
      ampl13 = 0.0,ampl14 = 0.0,ampl15 = 0.0,ampl16 = 0.0,
      ampl17 = 0.0,ampl18 = 0.0,ampl19 = 0.0,ampl20 = 0.0,
      ampl21 = 0.0,ampl22 = 0.0,ampl23 = 0.0,ampl24 = 0.0,
      ampl25 = 0.0,ampl26 = 0.0,ampl27 = 0.0;

//--- XY Graphs -------------------------------------------------------------
float  XCENTRE1  = 0.0, YCENTRE1  = 0.0, XMAX1  = 0.0, YMAX1  = 0.0,
       XCENTRE2  = 0.0, YCENTRE2  = 0.0, XMAX2  = 0.0, YMAX2  = 0.0,
       XCENTRE3  = 0.0, YCENTRE3  = 0.0, XMAX3  = 0.0, YMAX3  = 0.0,
       XCENTRE4  = 0.0, YCENTRE4  = 0.0, XMAX4  = 0.0, YMAX4  = 0.0,
       XCENTRE5  = 0.0, YCENTRE5  = 0.0, XMAX5  = 0.0, YMAX5  = 0.0,
       XCENTRE6  = 0.0, YCENTRE6  = 0.0, XMAX6  = 0.0, YMAX6  = 0.0,
       XCENTRE7  = 0.0, YCENTRE7  = 0.0, XMAX7  = 0.0, YMAX7  = 0.0,
       XCENTRE8  = 0.0, YCENTRE8  = 0.0, XMAX8  = 0.0, YMAX8  = 0.0,
       XCENTRE9  = 0.0, YCENTRE9  = 0.0, XMAX9  = 0.0, YMAX9  = 0.0,
       XCENTRE10 = 0.0, YCENTRE10 = 0.0, XMAX10 = 0.0, YMAX10 = 0.0,
       XCENTRE11 = 0.0, YCENTRE11 = 0.0, XMAX11 = 0.0, YMAX11 = 0.0;

//--- XYZ Graphs -------------------------------------------------------------
float XCENTRE = 0.0, YCENTRE = 0.0, ZCENTRE = 0.0;
float XMAX = 0.0, YMAX = 0.0, ZMAX = 0.0;
float PHIxyz = 0.0, PSIxyz = 0.0, THExyz = 0.0;


int XX;
int YY = 15;
int MY = 15;
int NM = 0;

//--- XY Graphs -------------------------------------------------------------

extern bool RXY,RXYZ,RYTV,DrawXY,DrawXYZ;
extern int NoOfRepeats, RNoOfYTV;

