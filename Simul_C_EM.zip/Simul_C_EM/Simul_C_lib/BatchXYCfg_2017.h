//---------------------------------------------------------------------------
#ifndef BatchXYCfg_2017
#define BatchXYCfg_2017
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <Buttons.hpp>
//---------------------------------------------------------------------------
class TBXYCfg : public TForm
{
__published:	// IDE-managed Components
      TLabel *Label1;
      TLabel *Label2;
      TLabel *Label3;
      TLabel *Label4;
      TLabel *Label5;
      TLabel *Label6;
      TLabel *Label7;
      TLabel *Label8;
      TLabel *Label9;
      TLabel *Label10;
      TLabel *Label11;
      TLabel *Label12;
      TLabel *Label13;
      TLabel *Label14;
      TLabel *Label15;
      TLabel *Label16;
      TLabel *Label17;
      TLabel *Label18;
      TLabel *Label19;
      TLabel *Label20;
      TLabel *Label21;
      TLabel *Label22;
      TLabel *Label23;
      TLabel *Label24;
      TLabel *Label25;
      TLabel *Label26;
      TLabel *Label27;
      TLabel *Label28;
      TLabel *Label29;
      TLabel *Label30;
      TLabel *Label31;
      TLabel *Label32;
      TLabel *Label33;
      TLabel *Label34;
      TLabel *Label35;
      TLabel *Label36;
      TLabel *Label37;
      TLabel *Label38;
      TLabel *Label39;
      TLabel *Label40;
      TLabel *Label41;
      TLabel *Label42;
      TLabel *Label43;
      TLabel *Label44;
      TLabel *Label45;
      TEdit *XC1;
      TEdit *XC2;
      TEdit *XC3;
      TEdit *XC4;
      TEdit *XC5;
      TEdit *XC6;
      TEdit *XC7;
      TEdit *XC8;
      TEdit *XC9;
      TEdit *XC10;
      TEdit *XC11;
      TEdit *YC1;
      TEdit *YC2;
      TEdit *YC3;
      TEdit *YC4;
      TEdit *YC5;
      TEdit *YC6;
      TEdit *YC7;
      TEdit *YC8;
      TEdit *YC9;
      TEdit *YC10;
      TEdit *YC11;
      TEdit *XM1;
      TEdit *XM2;
      TEdit *XM3;
      TEdit *XM4;
      TEdit *XM5;
      TEdit *XM6;
      TEdit *XM7;
      TEdit *XM8;
      TEdit *XM9;
      TEdit *XM10;
      TEdit *XM11;
      TEdit *YM1;
      TEdit *YM2;
      TEdit *YM3;
      TEdit *YM4;
      TEdit *YM5;
      TEdit *YM6;
      TEdit *YM7;
      TEdit *YM8;
      TEdit *YM9;
      TEdit *YM10;
      TEdit *YM11;
      TBitBtn *BXYDONE;
      TLabel *Label46;
      TLabel *Label47;
      TLabel *Label48;
      TLabel *Label49;
      void __fastcall FormCreate(TObject *Sender);
      void __fastcall BXYDONEClick(TObject *Sender);
private:	// User declarations
public:		// User declarations
      __fastcall TBXYCfg(TComponent* Owner);
};

struct BatchXY
{
  float XCENTRE1;
  float XCENTRE2;
  float XCENTRE3;
  float XCENTRE4;
  float XCENTRE5;
  float XCENTRE6;
  float XCENTRE7;
  float XCENTRE8;
  float XCENTRE9;
  float XCENTRE10;
  float XCENTRE11;
  float YCENTRE1;
  float YCENTRE2;
  float YCENTRE3;
  float YCENTRE4;
  float YCENTRE5;
  float YCENTRE6;
  float YCENTRE7;
  float YCENTRE8;
  float YCENTRE9;
  float YCENTRE10;
  float YCENTRE11;
  float XMAX1;
  float XMAX2;
  float XMAX3;
  float XMAX4;
  float XMAX5;
  float XMAX6;
  float XMAX7;
  float XMAX8;
  float XMAX9;
  float XMAX10;
  float XMAX11;
  float YMAX1;
  float YMAX2;
  float YMAX3;
  float YMAX4;
  float YMAX5;
  float YMAX6;
  float YMAX7;
  float YMAX8;
  float YMAX9;
  float YMAX10;
  float YMAX11;
};

//---------------------------------------------------------------------------
extern PACKAGE TBXYCfg *BXYCfg;
//---------------------------------------------------------------------------
#endif
