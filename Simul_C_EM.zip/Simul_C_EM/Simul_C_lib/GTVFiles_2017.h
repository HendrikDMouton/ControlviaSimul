//---------------------------------------------------------------------------

#ifndef GTVFiles_2017H
#define GTVFiles_2017H
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <Buttons.hpp>
#include <Dialogs.hpp>
#include <ComCtrls.hpp>
//---------------------------------------------------------------------------
class TFGTV : public TForm
{
__published:	// IDE-managed Components
      TLabel *NoOfColumns;
      TEdit *NoOfC;
      TEdit *NoOfHR;
      TLabel *NoOfHeaderRows;
      TOpenDialog *OpenDialogGTV;
      TSaveDialog *SaveDialogGTV;
      TButton *LoadGTV;
      TButton *SaveGTV;
      TBitBtn *Done;
      TBitBtn *Cancel;
      TProgressBar *ProgressBarL;
      TProgressBar *ProgressBarS;
      TButton *DisplayGTV;
      void __fastcall DoneClick(TObject *Sender);
      void __fastcall CancelClick(TObject *Sender);
      void __fastcall LoadGTVClick(TObject *Sender);
      void __fastcall SaveGTVClick(TObject *Sender);
      void __fastcall FormCreate(TObject *Sender);
      void __fastcall DisplayGTVClick(TObject *Sender);
      void __fastcall FormDestroy(TObject *Sender);
private:	// User declarations
public:		// User declarations
      __fastcall TFGTV(TComponent* Owner);
};
//---------------------------------------------------------------------------
struct GTVFile1
{
 float Sig1;
};

struct GTVFile2
{
 float Sig1;
 float Sig2;
};

struct GTVFile3
{
 float Sig1;
 float Sig2;
 float Sig3;
};

struct GTVFile4
{
 float Sig1;
 float Sig2;
 float Sig3;
 float Sig4;
};

struct GTVFile5
{
 float Sig1;
 float Sig2;
 float Sig3;
 float Sig4;
 float Sig5;
};

struct GTVFile6
{
 float Sig1;
 float Sig2;
 float Sig3;
 float Sig4;
 float Sig5;
 float Sig6;
};

struct GTVFile7
{
 float Sig1;
 float Sig2;
 float Sig3;
 float Sig4;
 float Sig5;
 float Sig6;
 float Sig7;
};

struct GTVFile8
{
 float Sig1;
 float Sig2;
 float Sig3;
 float Sig4;
 float Sig5;
 float Sig6;
 float Sig7;
 float Sig8;
};

struct GTVFile9
{
 float Sig1;
 float Sig2;
 float Sig3;
 float Sig4;
 float Sig5;
 float Sig6;
 float Sig7;
 float Sig8;
 float Sig9;
};

struct GTVFile10
{
 float Sig1;
 float Sig2;
 float Sig3;
 float Sig4;
 float Sig5;
 float Sig6;
 float Sig7;
 float Sig8;
 float Sig9;
 float Sig10;
};

struct GTVFile11
{
 float Sig1;
 float Sig2;
 float Sig3;
 float Sig4;
 float Sig5;
 float Sig6;
 float Sig7;
 float Sig8;
 float Sig9;
 float Sig10;
 float Sig11;
};

struct GTVFile12
{
 float Sig1;
 float Sig2;
 float Sig3;
 float Sig4;
 float Sig5;
 float Sig6;
 float Sig7;
 float Sig8;
 float Sig9;
 float Sig10;
 float Sig11;
 float Sig12;
};

struct GTVFile13
{
 float Sig1;
 float Sig2;
 float Sig3;
 float Sig4;
 float Sig5;
 float Sig6;
 float Sig7;
 float Sig8;
 float Sig9;
 float Sig10;
 float Sig11;
 float Sig12;
 float Sig13;
};

struct GTVFile14
{
 float Sig1;
 float Sig2;
 float Sig3;
 float Sig4;
 float Sig5;
 float Sig6;
 float Sig7;
 float Sig8;
 float Sig9;
 float Sig10;
 float Sig11;
 float Sig12;
 float Sig13;
 float Sig14;
};

struct GTVFile15
{
 float Sig1;
 float Sig2;
 float Sig3;
 float Sig4;
 float Sig5;
 float Sig6;
 float Sig7;
 float Sig8;
 float Sig9;
 float Sig10;
 float Sig11;
 float Sig12;
 float Sig13;
 float Sig14;
 float Sig15;
};

struct GTVFile16
{
 float Sig1;
 float Sig2;
 float Sig3;
 float Sig4;
 float Sig5;
 float Sig6;
 float Sig7;
 float Sig8;
 float Sig9;
 float Sig10;
 float Sig11;
 float Sig12;
 float Sig13;
 float Sig14;
 float Sig15;
 float Sig16;
};

struct GTVFile17
{
 float Sig1;
 float Sig2;
 float Sig3;
 float Sig4;
 float Sig5;
 float Sig6;
 float Sig7;
 float Sig8;
 float Sig9;
 float Sig10;
 float Sig11;
 float Sig12;
 float Sig13;
 float Sig14;
 float Sig15;
 float Sig16;
 float Sig17;
};

struct GTVFile18
{
 float Sig1;
 float Sig2;
 float Sig3;
 float Sig4;
 float Sig5;
 float Sig6;
 float Sig7;
 float Sig8;
 float Sig9;
 float Sig10;
 float Sig11;
 float Sig12;
 float Sig13;
 float Sig14;
 float Sig15;
 float Sig16;
 float Sig17;
 float Sig18;
};

struct GTVFile19
{
 float Sig1;
 float Sig2;
 float Sig3;
 float Sig4;
 float Sig5;
 float Sig6;
 float Sig7;
 float Sig8;
 float Sig9;
 float Sig10;
 float Sig11;
 float Sig12;
 float Sig13;
 float Sig14;
 float Sig15;
 float Sig16;
 float Sig17;
 float Sig18;
 float Sig19;
};

struct GTVFile20
{
 float Sig1;
 float Sig2;
 float Sig3;
 float Sig4;
 float Sig5;
 float Sig6;
 float Sig7;
 float Sig8;
 float Sig9;
 float Sig10;
 float Sig11;
 float Sig12;
 float Sig13;
 float Sig14;
 float Sig15;
 float Sig16;
 float Sig17;
 float Sig18;
 float Sig19;
 float Sig20;
};

struct GTVFile21
{
 float Sig1;
 float Sig2;
 float Sig3;
 float Sig4;
 float Sig5;
 float Sig6;
 float Sig7;
 float Sig8;
 float Sig9;
 float Sig10;
 float Sig11;
 float Sig12;
 float Sig13;
 float Sig14;
 float Sig15;
 float Sig16;
 float Sig17;
 float Sig18;
 float Sig19;
 float Sig20;
 float Sig21;
};

struct GTVFile22
{
 float Sig1;
 float Sig2;
 float Sig3;
 float Sig4;
 float Sig5;
 float Sig6;
 float Sig7;
 float Sig8;
 float Sig9;
 float Sig10;
 float Sig11;
 float Sig12;
 float Sig13;
 float Sig14;
 float Sig15;
 float Sig16;
 float Sig17;
 float Sig18;
 float Sig19;
 float Sig20;
 float Sig21;
 float Sig22;
};

struct GTVFile23
{
 float Sig1;
 float Sig2;
 float Sig3;
 float Sig4;
 float Sig5;
 float Sig6;
 float Sig7;
 float Sig8;
 float Sig9;
 float Sig10;
 float Sig11;
 float Sig12;
 float Sig13;
 float Sig14;
 float Sig15;
 float Sig16;
 float Sig17;
 float Sig18;
 float Sig19;
 float Sig20;
 float Sig21;
 float Sig22;
 float Sig23;
};

struct GTVFile24
{
 float Sig1;
 float Sig2;
 float Sig3;
 float Sig4;
 float Sig5;
 float Sig6;
 float Sig7;
 float Sig8;
 float Sig9;
 float Sig10;
 float Sig11;
 float Sig12;
 float Sig13;
 float Sig14;
 float Sig15;
 float Sig16;
 float Sig17;
 float Sig18;
 float Sig19;
 float Sig20;
 float Sig21;
 float Sig22;
 float Sig23;
 float Sig24;
};

struct GTVFile25
{
 float Sig1;
 float Sig2;
 float Sig3;
 float Sig4;
 float Sig5;
 float Sig6;
 float Sig7;
 float Sig8;
 float Sig9;
 float Sig10;
 float Sig11;
 float Sig12;
 float Sig13;
 float Sig14;
 float Sig15;
 float Sig16;
 float Sig17;
 float Sig18;
 float Sig19;
 float Sig20;
 float Sig21;
 float Sig22;
 float Sig23;
 float Sig24;
 float Sig25;
};

struct GTVFile26
{
 float Sig1;
 float Sig2;
 float Sig3;
 float Sig4;
 float Sig5;
 float Sig6;
 float Sig7;
 float Sig8;
 float Sig9;
 float Sig10;
 float Sig11;
 float Sig12;
 float Sig13;
 float Sig14;
 float Sig15;
 float Sig16;
 float Sig17;
 float Sig18;
 float Sig19;
 float Sig20;
 float Sig21;
 float Sig22;
 float Sig23;
 float Sig24;
 float Sig25;
 float Sig26;
};

struct GTVFile27
{
 float Sig1;
 float Sig2;
 float Sig3;
 float Sig4;
 float Sig5;
 float Sig6;
 float Sig7;
 float Sig8;
 float Sig9;
 float Sig10;
 float Sig11;
 float Sig12;
 float Sig13;
 float Sig14;
 float Sig15;
 float Sig16;
 float Sig17;
 float Sig18;
 float Sig19;
 float Sig20;
 float Sig21;
 float Sig22;
 float Sig23;
 float Sig24;
 float Sig25;
 float Sig26;
 float Sig27;
};

struct GTVFile28
{
 float Sig1;
 float Sig2;
 float Sig3;
 float Sig4;
 float Sig5;
 float Sig6;
 float Sig7;
 float Sig8;
 float Sig9;
 float Sig10;
 float Sig11;
 float Sig12;
 float Sig13;
 float Sig14;
 float Sig15;
 float Sig16;
 float Sig17;
 float Sig18;
 float Sig19;
 float Sig20;
 float Sig21;
 float Sig22;
 float Sig23;
 float Sig24;
 float Sig25;
 float Sig26;
 float Sig27;
 float Sig28;
};

struct GTVFile29
{
 float Sig1;
 float Sig2;
 float Sig3;
 float Sig4;
 float Sig5;
 float Sig6;
 float Sig7;
 float Sig8;
 float Sig9;
 float Sig10;
 float Sig11;
 float Sig12;
 float Sig13;
 float Sig14;
 float Sig15;
 float Sig16;
 float Sig17;
 float Sig18;
 float Sig19;
 float Sig20;
 float Sig21;
 float Sig22;
 float Sig23;
 float Sig24;
 float Sig25;
 float Sig26;
 float Sig27;
 float Sig28;
 float Sig29;
};

struct GTVFile30
{
 float Sig1;
 float Sig2;
 float Sig3;
 float Sig4;
 float Sig5;
 float Sig6;
 float Sig7;
 float Sig8;
 float Sig9;
 float Sig10;
 float Sig11;
 float Sig12;
 float Sig13;
 float Sig14;
 float Sig15;
 float Sig16;
 float Sig17;
 float Sig18;
 float Sig19;
 float Sig20;
 float Sig21;
 float Sig22;
 float Sig23;
 float Sig24;
 float Sig25;
 float Sig26;
 float Sig27;
 float Sig28;
 float Sig29;
 float Sig30;
};

//---------------------------------------------------------------------------
extern PACKAGE TFGTV *FGTV;
//---------------------------------------------------------------------------
#endif
