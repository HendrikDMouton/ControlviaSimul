/*****          SIMPROTO.H          *****/

#ifndef _SIM_PROTO
#define _SIM_PROTO

void SIMBATCH(void);
void BODEBATCH(void);
void INITSIM(void);
void InitVar(void);
void XYFrame(void);
void XYZFrame(void);
void YTFrame(void);
void BodeFrame(void);

void SIMUL_C(void);

/**    BODEFNC.CPP    **/

__declspec(dllimport) void BODECALC(double[3],double,double[3],double[3]);

/**    SIMFNC.CPP     **/

__declspec(dllimport) void SETSIGNAL(double,double[3]);
__declspec(dllimport) void ZSETSIGNAL(double,double[3]);
__declspec(dllimport) void CREATESIGNAL(double,double[3]);
__declspec(dllimport) void ZCREATESIGNAL(double,double[3]);
__declspec(dllimport) void SETP(double,double,double,double[3]);

__declspec(dllimport) void STEP(double,double,double[3]);
__declspec(dllimport) void ZSTEP(double,double,double[3]);
__declspec(dllimport) void PULSE(double,double,double,double[3]);
__declspec(dllimport) void PULSES(double,double,double,double,double[3]);
__declspec(dllimport) void RAMPPULSES(double,double,double,double,double[3]);
__declspec(dllimport) void SINE(double,double,double,double,double[3]);
__declspec(dllimport) void SQUARE(double,double,double,double,double[3]);
__declspec(dllimport) void TRIANGLE(double,double,double,double,double[3]);
__declspec(dllimport) void AMLINSWP(double,double,double,double,double,double,double[3]);
__declspec(dllimport) void AMPOWSWP(double,double,double,double,double,double,double,double[3]);
__declspec(dllimport) void FMLINSWP(double,double,double,double,double,double,double[3]);
__declspec(dllimport) void AMFMLINSWP(double,double,double,double,double,double,double,double[3]);
__declspec(dllimport) void NOISE(double,double,double[3]);
__declspec(dllimport) void GAUSSNOISE(double,double,double,double[3]);
__declspec(dllimport) void ZGAUSSNOISE(double,double,double,double[3]);

__declspec(dllimport) void SVARFGEN(double[3],const double[],double[3]);
__declspec(dllimport) void ZSVARFGEN(double[3],const double[],double[3]);
__declspec(dllimport) void DVARFGEN(double[3],double[3],const double[],double[3]);
__declspec(dllimport) void ZDVARFGEN(double[3],double[3],const double[],double[3]);
__declspec(dllimport) void TVARFGEN(double[3],double[3],double[3],const double[],double[3]);
__declspec(dllimport) void TELTIMEDIFF(double,double,const float[],double OUTP[3]);
__declspec(dllimport) void TELFGEN(double,const float[],int,double[3]);

__declspec(dllimport) void POSPEAK(double[3],double,double[3]);
__declspec(dllimport) void NEGPEAK(double[3],double,double[3]);
__declspec(dllimport) void AVG(double[3],double,double[3]);
__declspec(dllimport) void AVGperTIMESLOT(double[3],double,double,double[3]);
__declspec(dllimport) void RMS(double[3],double,double[3]);
__declspec(dllimport) void RMSperTIMESLOT(double[3],double,double,double[3]);
__declspec(dllimport) void ZRMS(double[3],double,double,double[3]);
__declspec(dllimport) void MINIM(double[3],double[3],double[3]);
__declspec(dllimport) void MAXIM(double[3],double[3],double[3]);
__declspec(dllimport)
void HISTOGRAM(double[3],double,double,int,double,double,double[500],long int[500],
               double[3],double[3]);
__declspec(dllimport)
void HISTONORM(double[3],double,double,int,double,double,double[500],long int[500],
               double[3],double[3]);

__declspec(dllimport) void QUANTISE(double[3],double,double,long,double[3]);
__declspec(dllimport) void A2D(double[3],double,double,double,long,double[3]);
__declspec(dllimport) void A2D_TPO(double[3],double,double,double,long,double[3],double[3]);
__declspec(dllimport) void D2D(double[3],double,double[3]);
__declspec(dllimport) void D2D_SHIFT(double[3],double,double,double[3]);
__declspec(dllimport) void D2D_TPO(double[3],double,double[3],double[3]);
__declspec(dllimport) void D2A(double[3],double[3]);
__declspec(dllimport) void D2A_FOH(double[3],double,double[3]);
/*
__declspec(dllimport) void MICROSTART(float);
__declspec(dllimport) void NORMAL2MICRO(double[3],double[3]);
__declspec(dllimport) void MICROEND(__declspec(dllimport) void);
__declspec(dllimport) void MICRO2NORMAL(double[3],double[3]);
*/
__declspec(dllimport) void SUM(double[3],double[3],double[3]);
__declspec(dllimport) void ZSUM(double[3],double[3],double[3]);
__declspec(dllimport) void DIFF(double[3],double[3],double[3]);
__declspec(dllimport) void ZDIFF(double[3],double[3],double[3]);
__declspec(dllimport) void BIQUAD(double[3],double,double,double,double,double,double,double[3]);
__declspec(dllimport) void ZBIQUAD(double[3],double,double,double,double,double,double,double[3]);
__declspec(dllimport) void ZBIQUAD_f(double[3],double,double,double,double,double,double,double[3]);
__declspec(dllimport) void LEADLAG(double[3],double,double,double,double,double[3]);
__declspec(dllimport) void ZLEADLAG(double[3],double,double,double,double,double[3]);
__declspec(dllimport) void INTEGR(double[3],double,double[3]);
__declspec(dllimport) void SIMPSON_INTEGR(double[3],double,double[3]);
__declspec(dllimport) void ADAMS_INTEGR(double[3],double,double[3]);
__declspec(dllimport) void DERIV(double[3],double,double[3]);
__declspec(dllimport) void GAIN(double[3],double,double[3]);
__declspec(dllimport) void ZGAIN(double[3],double,double[3]);

__declspec(dllimport) void SINGAIN(double[3],double[3],double[3]);
__declspec(dllimport) void ZSINGAIN(double[3],double[3],double[3]);
__declspec(dllimport) void COSGAIN(double[3],double[3],double[3]);
__declspec(dllimport) void ZCOSGAIN(double[3],double[3],double[3]);
__declspec(dllimport) void COSSINSUM(double[3],double[3],double[3],double[3]);
__declspec(dllimport) void ZCOSSINSUM(double[3],double[3],double[3],double[3]);
__declspec(dllimport) void COSSINDIFF(double[3],double[3],double[3],double[3]);
__declspec(dllimport) void ZCOSSINDIFF(double[3],double[3],double[3],double[3]);
__declspec(dllimport) void PIOGRAM(double[3],double[3],double[3],double[3],double[3]);

__declspec(dllimport) void LNAMP(double[3],double,double[3]);
__declspec(dllimport) void OPAMP(double[3],double[3],double,double,double,double[3]);

__declspec(dllimport) void FWR(double[3],double[3]);
__declspec(dllimport) void ZFWR(double[3],double[3]);
__declspec(dllimport) void HWR(double[3],double[3]);
__declspec(dllimport) void ZHWR(double[3],double[3]);
__declspec(dllimport) void PEAKDET(double[3],double,double,double,double[3]);
__declspec(dllimport) void SETVAL(double[3],double,double[3]);
__declspec(dllimport) void SANDH(double[3],double[3],double[3]);
__declspec(dllimport) void SWITCH(double[3],double[3],double[3],double[3]);
__declspec(dllimport) void ZSWITCH(double[3],double[3],double[3],double[3]);
__declspec(dllimport) void MUX(double[3],double[3],double[3],double[3],double[3],double[3],double[3]);
__declspec(dllimport) void ZMUX(double[3],double[3],double[3],double[3],double[3],double[3],double[3]);

__declspec(dllimport) void LIMIT(double,double,double[3]);
__declspec(dllimport) void PLAY(double,double,double[3]);
__declspec(dllimport) void ZLIMIT(double,double,double[3]);

__declspec(dllimport) void DELCOMP(double[3],double[3]);
__declspec(dllimport) void DELAY(double[3],double,double[3]);
__declspec(dllimport) void ZDELAY(double[3],double,double,double[3]);
__declspec(dllimport) void VARDELAY(double[3],double,double,double[3]);
__declspec(dllimport) void ZVARDELAY(double[3],double,double,double,double[3]);
__declspec(dllimport) void LO2HI_DELAY(double[3],double,double[3]);
__declspec(dllimport) void LO2HI_ZDELAY(double[3],double,double,double[3]);
__declspec(dllimport) void HI2LO_DELAY(double[3],double,double[3]);
__declspec(dllimport) void HI2LO_ZDELAY(double[3],double,double,double[3]);

__declspec(dllimport) void DEADBAND(double[3],double,double[3]);
__declspec(dllimport) void STICTION(double[3],double[3],double,double,double,double,
			  double[3],double[3],double[3],double[3]);
__declspec(dllimport) void STICLIM(double[3],double[3],double,double,double,double,double,double,
			 double[3],double[3],double[3],double[3],double[3]);

__declspec(dllimport) void COMPR(double[3],double[3],double[3]);
__declspec(dllimport) void ZCOMPR(double[3],double[3],double[3]);
__declspec(dllimport) void MONOSTAB(double[3],int,double,double[3]);
__declspec(dllimport) void ZMONOSTAB(double[3],double,int,double,double[3]);
__declspec(dllimport) void RTMONO(double[3],int,double,double[3]);
__declspec(dllimport) void ZRTMONO(double[3],double,int,double,double[3]);
__declspec(dllimport) void SIGAND(double[3],double[3],double[3]);
__declspec(dllimport) void ZSIGAND(double[3],double[3],double[3]);
__declspec(dllimport) void SIGOR(double[3],double[3],double[3]);
__declspec(dllimport) void ZSIGOR(double[3],double[3],double[3]);
__declspec(dllimport) void SIGXOR(double[3],double[3],double[3]);
__declspec(dllimport) void ZSIGXOR(double[3],double[3],double[3]);
__declspec(dllimport) void SIGINV(double[3],double[3]);
__declspec(dllimport) void ZSIGINV(double[3],double[3]);

__declspec(dllimport)
void SS1(double[3],
         double,
         double,
         double[3],
         double,
         double,
			double[3]);
__declspec(dllimport)
void ZSS1(double[3],
          double,
          double,
          double[3],
          double,
          double,
			double[3]);
__declspec(dllimport)
void SS2(double[3],
         double,double,
         double,double,
         double,double,
         double[3],double[3],
         double,double,
         double,
			double[3]);
__declspec(dllimport)
void ZSS2(double[3],
          double,double,
          double,double,
          double,double,
          double[3],double[3],
          double,double,
          double,
			double[3]);
__declspec(dllimport)
void SS3(double[3],
         double,double,double,
         double,double,double,
         double,double,double,
         double,double,double,
         double[3],double[3],double[3],
         double,double,double,
         double,
			double[3]);
__declspec(dllimport)
void ZSS3(double[3],
          double,double,double,
          double,double,double,
          double,double,double,
          double,double,double,
          double[3],double[3],double[3],
          double,double,double,
          double,
			double[3]);
__declspec(dllimport)
void SS4(double[3],
         double,double,double,double,
         double,double,double,double,
         double,double,double,double,
         double,double,double,double,
         double,double,double,double,
         double[3],double[3],double[3],double[3],
         double,double,double,double,
         double,
			double[3]);
__declspec(dllimport)
void ZSS4(double[3],
          double,double,double,double,
          double,double,double,double,
          double,double,double,double,
          double,double,double,double,
          double,double,double,double,
          double[3],double[3],double[3],double[3],
          double,double,double,double,
          double,
			double[3]);
__declspec(dllimport)
void SS5(double[3],
         double,double,double,double,double,
         double,double,double,double,double,
         double,double,double,double,double,
         double,double,double,double,double,
         double,double,double,double,double,
         double,double,double,double,double,
         double[3],double[3],double[3],double[3],double[3],
         double,double,double,double,double,
         double,
			double[3]);
__declspec(dllimport)
void SS(double[3],int,
        double[],double[],double[],double,
        double[],double[3]);
__declspec(dllimport)
void ZSS(double[3],int,
         double[],double[],double[],double,
         double[],double[3]);

__declspec(dllimport) void Grnd_Refl(void);

/**     SIMMAT.C     **/

__declspec(dllimport)
void MATASS(double,double,double,
            double,double,double,
            double,double,double,
			double[3][3]);
__declspec(dllimport)
void ZMATASS(double,double,double,
             double,double,double,
             double,double,double,
			 double[3][3]);
__declspec(dllimport) void MATNEG(double[3][3],double[3][3]);
__declspec(dllimport) void ZMATNEG(double[3][3],double[3][3]);
__declspec(dllimport) void MATTRP(double[3][3],double[3][3]);
__declspec(dllimport) void ZMATTRP(double[3][3],double[3][3]);
__declspec(dllimport) void MATINV(double[3][3],double[3][3]);
__declspec(dllimport) void ZMATINV(double[3][3],double[3][3]);
__declspec(dllimport)
void MAT6x6INV(double[3][3],double[3][3],double[3][3],double[3][3],
               double[3][3],double[3][3],double[3][3],double[3][3]);
__declspec(dllimport)
void ZMAT6x6INV(double[3][3],double[3][3],double[3][3],double[3][3],
                double[3][3],double[3][3],double[3][3],double[3][3]);
__declspec(dllimport) void MATDERIV(double[3][3],double[3][3],double[3][3]);
__declspec(dllimport) void ZMATDERIV(double[3][3],double,double[3][3],double[3][3]);
__declspec(dllimport) void MMMULT(double[3][3],double[3][3],double[3][3]);
__declspec(dllimport) void ZMMMULT(double[3][3],double[3][3],double[3][3]);
__declspec(dllimport) void MMSUM(double[3][3],double[3][3],double[3][3]);
__declspec(dllimport) void ZMMSUM(double[3][3],double[3][3],double[3][3]);
__declspec(dllimport) void MMDIFF(double[3][3],double[3][3],double[3][3]);
__declspec(dllimport) void ZMMDIFF(double[3][3],double[3][3],double[3][3]);

__declspec(dllimport) void MVMULT(double[3][3],double[3],double[3],double[3],double[3],double[3],double[3]);
__declspec(dllimport) void ZMVMULT(double[3][3],double[3],double[3],double[3],double[3],double[3],double[3]);
__declspec(dllimport) void VMMULT(double[3],double[3],double[3],double[3][3],double[3],double[3],double[3]);
__declspec(dllimport) void ZVMMULT(double[3],double[3],double[3],double[3][3],double[3],double[3],double[3]);
__declspec(dllimport) void PMMULT(double[3],double[3][3],double[3]);

__declspec(dllimport) void MSMULT(double[3][3],double[3],double[3][3]);
__declspec(dllimport) void ZMSMULT(double[3][3],double[3],double[3][3]);

__declspec(dllimport) void VVMAT(double[3],double[3],double[3],double[3],double[3],double[3],double[3][3]);
__declspec(dllimport) void ZVVMAT(double[3],double[3],double[3],double[3],double[3],double[3],double[3][3]);
__declspec(dllimport)
void VVCROSS(double[3],double[3],double[3],double[3],double[3],double[3],
             double[3],double[3],double[3]);
__declspec(dllimport)
void ZVVCROSS(double[3],double[3],double[3],double[3],double[3],double[3],
              double[3],double[3],double[3]);
__declspec(dllimport) void VVDOT(double[3],double[3],double[3],double[3],double[3],double[3],double[3]);
__declspec(dllimport) void ZVVDOT(double[3],double[3],double[3],double[3],double[3],double[3],double[3]);
__declspec(dllimport)
void VVSUM(double[3],double[3],double[3],double[3],double[3],double[3],
           double[3],double[3],double[3]);
__declspec(dllimport)
void ZVVSUM(double[3],double[3],double[3],double[3],double[3],double[3],
            double[3],double[3],double[3]);
__declspec(dllimport)
void VVDIFF(double[3],double[3],double[3],double[3],double[3],double[3],
            double[3],double[3],double[3]);
__declspec(dllimport)
void ZVVDIFF(double[3],double[3],double[3],double[3],double[3],double[3],
             double[3],double[3],double[3]);

__declspec(dllimport) void VSMULT(double[3],double[3],double[3],double[3],double[3],double[3],double[3]);
__declspec(dllimport) void ZVSMULT(double[3],double[3],double[3],double[3],double[3],double[3],double[3]);

__declspec(dllimport) void MnmMmrMULT(int,int,int,double MINP1[],double MINP2[],double MOUTP[]);
__declspec(dllimport) void ZMnmMmrMULT(int,int,int,double MINP1[],double MINP2[],double MOUTP[]);
__declspec(dllimport) void MnmMnmSUM(int,int,double MINP1[],double MINP2[],double MOUTP[]);
__declspec(dllimport) void ZMnmMnmSUM(int,int,double MINP1[],double MINP2[],double MOUTP[]);
__declspec(dllimport) void MnmMnmDIFF(int,int,double MINP1[],double MINP2[],double MOUTP[]);
__declspec(dllimport) void ZMnmMnmDIFF(int,int,double MINP1[],double MINP2[],double MOUTP[]);
__declspec(dllimport) void MnmTRP(int,int,double MINP[],double MOUTP[]);
__declspec(dllimport) void ZMnmTRP(int,int,double MINP[],double MOUTP[]);
__declspec(dllimport) void MnnINV(int,double MINP[],double MOUTP[]);
__declspec(dllimport) void ZMnnINV(int,double MINP[],double MOUTP[]);
__declspec(dllimport) void MnmINT(int,int,double MINP[],double MOUTP[]);
__declspec(dllimport) void ZMnmINT(int,int,double,double MINP[],double MOUTP[]);
__declspec(dllimport) void MATVALUES(double MAT[3][3]);
__declspec(dllimport) void MnmVALUES(double TIME, int n, int m, double MAT[]);

/***    	VARIOUS DISCIPLINES 		***/

//       DETECTORS & RETICLES

__declspec(dllimport) void AMRET(double[3],double[3],double,double,double,double[3],double[3]);
__declspec(dllimport) void RETDET(double[3],double[3],double,double,double,double,double,double[3]);
__declspec(dllimport) void GENDET(double[3],double[3],double,double,double,double[3],double[3],double[3]);
__declspec(dllimport) void DETARRAY(double[3],double,double,double,long,double,double[3]);
__declspec(dllimport)
void ONEQUAD(double,double,double,double[3]);
__declspec(dllimport)
void FOURQUAD(double[3],double[3],double,double,double,
              double[3],double[3],double[3],double[3]);

//			ATMOSPHERE

__declspec(dllimport) void ATMO(double[3],double[3],double[3],double[3],double[3],double[3]);
__declspec(dllimport) void ATMO_T_Tsl(double[3],double[3],double[3],double[3]);
__declspec(dllimport) void ATMO_p_Tsl(double[3],double[3],double[3],double[3]);
//	ATMO_rho_Tsl is problematic because slope is about zero around height of 6000 m
//		=> Tsl cannot be resolved

//                      COSMOS

__declspec(dllimport)
void GEOSTAT(double[3],double[3],double[3],
             double[3],double[3],double[3],
             double[3],double[3],double[3],double[3]);
__declspec(dllimport)
void BASE2GEOSTAT(double[3],double[3],double[3],
                  double[3],double[3],double[3],
                  double[3],double[3],double[3],
                  double[3],double[3],double[3],double[3]);

/**         SIMGRPHS.C          **/

__declspec(dllimport)
void YTVALUESonYTGRAPHS(double TIME, double SIGNAL1[3], double SIGNAL2[3], double SIGNAL3[3],
                        double SIGNAL4[3], double SIGNAL5[3], double SIGNAL6[3]);

__declspec(dllimport)
void YTVALUES(double SIGNAL1[3], double SIGNAL2[3], double SIGNAL3[3],
              double SIGNAL4[3], double SIGNAL5[3], double SIGNAL6[3],
              double SIGNAL7[3], double SIGNAL8[3], double SIGNAL9[3],
              double SIGNAL10[3]);
__declspec(dllimport)
void YTDRAW(double SIGNAL1[3], double SIGNAL2[3], double SIGNAL3[3],
            double SIGNAL4[3], double SIGNAL5[3], double SIGNAL6[3],
            double SIGNAL7[3], double SIGNAL8[3], double SIGNAL9[3],
            double SIGNAL10[3],double SIGNAL11[3],double SIGNAL12[3],
            double SIGNAL13[3],double SIGNAL14[3],double SIGNAL15[3],
            double SIGNAL16[3],double SIGNAL17[3],double SIGNAL18[3],
            double SIGNAL19[3],double SIGNAL20[3],double SIGNAL21[3],
            double SIGNAL22[3],double SIGNAL23[3],double SIGNAL24[3],
            double SIGNAL25[3],double SIGNAL26[3],double SIGNAL27[3]);

__declspec(dllimport)
void XYDRAW(double SIGNAL1[3],double SIGNAL2[3],
            double SIGNAL3[3],double SIGNAL4[3],
            double SIGNAL5[3],double SIGNAL6[3],
            double SIGNAL7[3],double SIGNAL8[3],
            double SIGNAL9[3],double SIGNAL10[3],
            double SIGNAL11[3],double SIGNAL12[3],
            double SIGNAL13[3],double SIGNAL14[3],
            double SIGNAL15[3],double SIGNAL16[3],
            double SIGNAL17[3],double SIGNAL18[3],
            double SIGNAL19[3],double SIGNAL20[3],
            double SIGNAL21[3],double SIGNAL22[3]);

__declspec(dllimport)
void XYZ1DRAW(double SIGNAL1[3], double SIGNAL2[3], double SIGNAL3[3]);
__declspec(dllimport)
void XYZ2DRAW(double SIGNAL1[3], double SIGNAL2[3], double SIGNAL3[3],
              double SIGNAL4[3], double SIGNAL5[3], double SIGNAL6[3]);
__declspec(dllimport)
void XYZ3DRAW(double SIGNAL1[3], double SIGNAL2[3], double SIGNAL3[3],
              double SIGNAL4[3], double SIGNAL5[3], double SIGNAL6[3],
              double SIGNAL7[3], double SIGNAL8[3], double SIGNAL9[3]);
__declspec(dllimport)
void XYZ4DRAW(double SIGNAL1[3], double SIGNAL2[3], double SIGNAL3[3],
              double SIGNAL4[3], double SIGNAL5[3], double SIGNAL6[3],
              double SIGNAL7[3], double SIGNAL8[3], double SIGNAL9[3],
              double SIGNAL10[3], double SIGNAL11[3], double SIGNAL12[3]);
__declspec(dllimport)
void XYZ5DRAW(double SIGNAL1[3], double SIGNAL2[3], double SIGNAL3[3],
              double SIGNAL4[3], double SIGNAL5[3], double SIGNAL6[3],
              double SIGNAL7[3], double SIGNAL8[3], double SIGNAL9[3],
              double SIGNAL10[3], double SIGNAL11[3], double SIGNAL12[3],
              double SIGNAL13[3], double SIGNAL14[3], double SIGNAL15[3]);
__declspec(dllimport)
void XYZ10DRAW(double SIGNAL1[3], double SIGNAL2[3], double SIGNAL3[3],
               double SIGNAL4[3], double SIGNAL5[3], double SIGNAL6[3],
               double SIGNAL7[3], double SIGNAL8[3], double SIGNAL9[3],
               double SIGNAL10[3], double SIGNAL11[3], double SIGNAL12[3],
               double SIGNAL13[3], double SIGNAL14[3], double SIGNAL15[3],
               double SIGNAL16[3], double SIGNAL17[3], double SIGNAL18[3],
               double SIGNAL19[3], double SIGNAL20[3], double SIGNAL21[3],
               double SIGNAL22[3], double SIGNAL23[3], double SIGNAL24[3],
               double SIGNAL25[3], double SIGNAL26[3], double SIGNAL27[3],
               double SIGNAL28[3], double SIGNAL29[3], double SIGNAL30[3]);
__declspec(dllimport)
void XPYZ1DRAW(double SIGNAL1[3], double SIGNAL2[3], double SIGNAL3[3]);
__declspec(dllimport)
void XPYZ2DRAW(double SIGNAL1[3], double SIGNAL2[3], double SIGNAL3[3],
               double SIGNAL4[3], double SIGNAL5[3], double SIGNAL6[3]);
__declspec(dllimport)
void XPYZ3DRAW(double SIGNAL1[3], double SIGNAL2[3], double SIGNAL3[3],
               double SIGNAL4[3], double SIGNAL5[3], double SIGNAL6[3],
               double SIGNAL7[3], double SIGNAL8[3], double SIGNAL9[3]);


 extern int JMsimulc,JSsimulc,JDsimulc,JDLHsimulc,J123mem,JMmem,JSmem,JDmem;

 extern double Tsimulc;
 extern float TSTART, TDELT, TEND, TPLOT, STARTYT, STARTMAT;
 extern int NoOfGraphs,YTVCOUNT;
 extern int ChoiceBorSim;


//      FMatVis
 extern int cols,rows;
 extern double TIMEG;

//      Batch runs
 extern int BatCase;
 extern bool BbXYZ;
 extern bool RXY,RXYZ,RYTV;
 extern int NoOfRepeats;
 extern int NumYT;
 extern bool EEYTS;
 extern int NumXY;
 extern bool EEXYS;
 extern int NumXYZ;
 extern bool EEXYZS;
 extern float MXYZ[3][3];
 extern float XFxyz, YFxyz, ZFxyz, XSxyz, YSxyz, ZSxyz;
 extern int NumBode;
 extern int BNoOfRepeats;


#endif //include protection
