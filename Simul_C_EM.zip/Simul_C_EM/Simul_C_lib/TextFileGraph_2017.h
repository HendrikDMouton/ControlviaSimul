//---------------------------------------------------------------------------
#ifndef TextFileGraph_2017
#define TextFileGraph_2017
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <Chart.hpp>
#include <ExtCtrls.hpp>
#include <Series.hpp>
#include <TeEngine.hpp>
#include <TeeProcs.hpp>
#include <Dialogs.hpp>
//---------------------------------------------------------------------------
class TGraphTextFile : public TForm
{
__published:	// IDE-managed Components
      TChart *Chart1;
      TLineSeries *Series1;
      TButton *PrintL;
      TButton *Cancel;
      TPrintDialog *PrintDialog;
      TButton *PrintP;
      TButton *SaveC;
      TSaveDialog *SaveDialog1;
      TLabel *Label1;
      void __fastcall PrintLClick(TObject *Sender);
      void __fastcall CancelClick(TObject *Sender);
      void __fastcall PrintPClick(TObject *Sender);
      void __fastcall SaveCClick(TObject *Sender);
      void __fastcall Chart1MouseMove(TObject *Sender, TShiftState Shift,
          int X, int Y);
private:	// User declarations
public:		// User declarations
      __fastcall TGraphTextFile(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TGraphTextFile *GraphTextFile;
//---------------------------------------------------------------------------
#endif
