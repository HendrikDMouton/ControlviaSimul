//---------------------------------------------------------------------------
#ifndef RBode_2017
#define RBode_2017
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <Buttons.hpp>
//---------------------------------------------------------------------------
class TRBodeSimulation : public TForm
{
__published:	// IDE-managed Components
        TBitBtn *RBodeDone;
        TBitBtn *RBodeCancel;
        TEdit *BodeNORepeats;
        TLabel *NoofRepeats;
      TBitBtn *CreateBodeSetupFile;
        TLabel *Label1;
        void __fastcall RBodeDoneClick(TObject *Sender);
        void __fastcall RBodeCancelClick(TObject *Sender);
      void __fastcall CreateBodeSetupFileClick(TObject *Sender);
      void __fastcall FormDestroy(TObject *Sender);
private:	// User declarations
public:		// User declarations
        __fastcall TRBodeSimulation(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TRBodeSimulation *RBodeSimulation;
//---------------------------------------------------------------------------
#endif
