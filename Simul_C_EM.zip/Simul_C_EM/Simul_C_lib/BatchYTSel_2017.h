//---------------------------------------------------------------------------
#ifndef BatchYTSel_2017
#define BatchYTSel_2017
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <Buttons.hpp>
#include <Dialogs.hpp>
#include <FileCtrl.hpp>
//---------------------------------------------------------------------------
class TBYTSel : public TForm
{
__published:	// IDE-managed Components
      TListBox *ListBox1;
      TBitBtn *Accept;
      TBitBtn *Cancel;
      TSaveDialog *SaveDialogBYT;
      TOpenDialog *OpenDialogCFGBYT;
        TLabel *Label1;
      void __fastcall CancelClick(TObject *Sender);
      void __fastcall ListBox1MouseUp(TObject *Sender, TMouseButton Button,
          TShiftState Shift, int X, int Y);
      void __fastcall AcceptClick(TObject *Sender);
      void __fastcall FormCreate(TObject *Sender);
      void __fastcall FormDestroy(TObject *Sender);
private:	// User declarations
public:		// User declarations
      __fastcall TBYTSel(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TBYTSel *BYTSel;
//---------------------------------------------------------------------------
#endif
