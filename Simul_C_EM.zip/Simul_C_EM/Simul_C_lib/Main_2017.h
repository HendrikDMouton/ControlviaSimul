//---------------------------------------------------------------------------

#ifndef _Main
#define _Main

//#ifndef SIMULINK

//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <ExtCtrls.hpp>
#include <Menus.hpp>
#include <Dialogs.hpp>
#include <ComCtrls.hpp>
#include <Printers.hpp>
#include <FileCtrl.hpp>
#include <Buttons.hpp>
#include <stdio.h>
#include <math.h>
//---------------------------------------------------------------------------
class TForm1 : public TForm
{
__published:	// IDE-managed Components
        TPaintBox *PaintBox1;
        TPanel *Panel1;
        TMainMenu *MainMenu;
        TMenuItem *Selections;
        TMenuItem *Simulate;
        TMenuItem *Printing;
        TMenuItem *SaveGraphs;
        TMenuItem *DisplayGraphs;
        TMenuItem *Appearance;
        TMenuItem *Exit;
        TMenuItem *SelBodePlot;
        TMenuItem *RBodePlots;
        TMenuItem *N7;
        TMenuItem *SelTimePlots;
        TMenuItem *RTimePlots;
        TMenuItem *N8;
        TMenuItem *NumericSimulation;
        TMenuItem *SimBodePlot;
        TMenuItem *N9;
        TMenuItem *SimTimePlots;
        TMenuItem *Invert;
        TOpenDialog *OpenDialogGraphYT;
        TSaveDialog *SaveDialogGraphs;
        TPrintDialog *PrintDialog;
        TMenuItem *ViewYTV;
        TMenuItem *DisplaySavedYTGraph;
        TMenuItem *DisplaySavedBodePlot;
        TPrinterSetupDialog *PrinterSetupDialog;
        TOpenDialog *OpenDialogCFGYT;
        TSaveDialog *SaveDialogCFGYT;
        TMenuItem *N13;
        TMenuItem *DisplayXYGraph;
        TPaintBox *PaintBox3;
        TMenuItem *DisplaySavedXYGraph;
        TMenuItem *DisplayXYZGraph;
        TMenuItem *DisplaySavedXYZGraph;
        TPaintBox *PaintBox4;
        TOpenDialog *OpenDialogGraphXY;
        TOpenDialog *OpenDialogGraphXYZ;
        TOpenDialog *OpenDialogGraphBode;
        TStatusBar *StatusBar;
        TMenuItem *PPortrait;
        TMenuItem *PLandscape;
        TOpenDialog *OpenDialogCFGBode;
        TSaveDialog *SaveDialogCFGBode;
        TOpenDialog *OpenDialogYTV;
        TFileListBox *FileListBoxYT;
        TFileListBox *FileListBoxXY;
        TFileListBox *FileListBoxXYZ;
        TFileListBox *FileListBoxBode;
        TBitBtn *DisplayClear;
        TSaveDialog *SaveDialogTXT;
        TScrollBox *ScrollBox1;
        TImage *Image1;
        TMenuItem *DisplYTG;
        TMenuItem *DisplXYG;
        TMenuItem *DisplXYZG;
        TSaveDialog *SaveDialogCFGXY;
        TOpenDialog *OpenDialogCFGXY;
        TOpenDialog *OpenDialogCFGXYZ;
        TSaveDialog *SaveDialogCFGXYZ;
        TMenuItem *ViewCurrentYTValues;
        TMenuItem *ViewSavedYTValues;
      TMenuItem *TextFileProc;
      TMenuItem *TFSignal1;
      TMenuItem *TFSignal2;
      TMenuItem *TFSignal3;
      TMenuItem *TFSignal4;
      TMenuItem *TFSignal5;
      TMenuItem *TFSignal6;
      TMenuItem *TFSignal7;
      TMenuItem *TFSignal8;
      TMenuItem *TFSignal9;
      TMenuItem *TFSignal10;
      TOpenDialog *OpenDialogCFGBYT;
      TOpenDialog *OpenDialogCFGBXY;
      TOpenDialog *OpenDialogCFGBXYZ;
      TOpenDialog *OpenDialogCFGBBode;
//      TMenuItem *GTV;
      TMenuItem *ViewCurrentMATValues;
      TMenuItem *N2;
      TMenuItem *ViewSavedMATValues;
      TImage *Image2;
      TScrollBox *ScrollBox2;
        TScrollBox *ScrollBox3;
        TImage *Image3;
        TMenuItem *N1;
        TMenuItem *ViewCnmMATValues;
        TMenuItem *ViewSnmMATValues;
        TMenuItem *DisplayMatVis;
        TFileListBox *FileListBoxMatNM;
        TSaveDialog *SaveDialogMatNM;
        TMenuItem *DisplaySavedVisMat;
        TFileListBox *FileListBoxMATVIS;
        TBitBtn *GraphDel;
        TFileListBox *FileListBoxYTVals;
        TFileListBox *FileListBoxMATVals;
        TBitBtn *ImageClose;
        void __fastcall ExitClick(TObject *Sender);
        void __fastcall FormCreate(TObject *Sender);
        void __fastcall FormDestroy(TObject *Sender);
        void __fastcall FormClose(TObject *Sender, TCloseAction &Action);
        void __fastcall PaintBox1Paint(TObject *Sender);
        void __fastcall PaintBox4MouseMove(TObject *Sender,
          TShiftState Shift, int X, int Y);
        void __fastcall SimBodePlotClick(TObject *Sender);
        void __fastcall PPortraitClick(TObject *Sender);
        void __fastcall PLandscapeClick(TObject *Sender);
        void __fastcall SaveGraphsClick(TObject *Sender);
        void __fastcall DisplayXYGraphClick(TObject *Sender);
        void __fastcall DisplayXYZGraphClick(TObject *Sender);
        void __fastcall DisplaySavedBodePlotClick(TObject *Sender);
        void __fastcall DisplaySavedYTGraphClick(TObject *Sender);
        void __fastcall DisplaySavedXYGraphClick(TObject *Sender);
        void __fastcall DisplaySavedXYZGraphClick(TObject *Sender);
        void __fastcall InvertClick(TObject *Sender);
        void __fastcall RBodePlotsClick(TObject *Sender);
        void __fastcall FileListBoxYTMouseUp(TObject *Sender,
          TMouseButton Button, TShiftState Shift, int X, int Y);
        void __fastcall FileListBoxXYMouseUp(TObject *Sender,
          TMouseButton Button, TShiftState Shift, int X, int Y);
        void __fastcall FileListBoxBodeMouseUp(TObject *Sender,
          TMouseButton Button, TShiftState Shift, int X, int Y);
        void __fastcall FileListBoxXYZMouseUp(TObject *Sender,
          TMouseButton Button, TShiftState Shift, int X, int Y);
        void __fastcall DisplayClearClick(TObject *Sender);
        void __fastcall DisplYTGClick(TObject *Sender);
        void __fastcall DisplXYGClick(TObject *Sender);
        void __fastcall DisplXYZGClick(TObject *Sender);
        void __fastcall RTimePlotsClick(TObject *Sender);
        void __fastcall SelBodePlotClick(TObject *Sender);
        void __fastcall SelTimePlotsClick(TObject *Sender);
        void __fastcall ViewCurrentYTValuesClick(TObject *Sender);
        void __fastcall ViewSavedYTValuesClick(TObject *Sender);
      void __fastcall TFSignal1Click(TObject *Sender);
      void __fastcall TFSignal2Click(TObject *Sender);
      void __fastcall TFSignal3Click(TObject *Sender);
      void __fastcall TFSignal4Click(TObject *Sender);
      void __fastcall TFSignal5Click(TObject *Sender);
      void __fastcall TFSignal6Click(TObject *Sender);
      void __fastcall TFSignal7Click(TObject *Sender);
      void __fastcall TFSignal8Click(TObject *Sender);
      void __fastcall TFSignal9Click(TObject *Sender);
      void __fastcall TFSignal10Click(TObject *Sender);
      void __fastcall TextFileProcClick(TObject *Sender);
//      void __fastcall GTVClick(TObject *Sender);
      void __fastcall ViewCurrentMATValuesClick(TObject *Sender);
      void __fastcall ViewSavedMATValuesClick(TObject *Sender);
        void __fastcall ViewCnmMATValuesClick(TObject *Sender);
        void __fastcall ViewSnmMATValuesClick(TObject *Sender);
        void __fastcall DisplayMatVisClick(TObject *Sender);
        void __fastcall FileListBoxMatNMMouseUp(TObject *Sender,
          TMouseButton Button, TShiftState Shift, int X, int Y);
        void __fastcall FileListBoxMATVISMouseUp(TObject *Sender,
          TMouseButton Button, TShiftState Shift, int X, int Y);
        void __fastcall DisplaySavedVisMatClick(TObject *Sender);
        void __fastcall GraphDelClick(TObject *Sender);
        void __fastcall FileListBoxMATValsMouseUp(TObject *Sender,
          TMouseButton Button, TShiftState Shift, int X, int Y);
        void __fastcall FileListBoxYTValsMouseUp(TObject *Sender,
          TMouseButton Button, TShiftState Shift, int X, int Y);
        void __fastcall ImageCloseClick(TObject *Sender);

private:	// User declarations
        void __fastcall OnHint(TObject *Sender);
public:		// User declarations
        Graphics::TBitmap*  CurrentBitMap;
        Graphics::TBitmap*  WorkSpaceBitMapYT;
        Graphics::TBitmap*  WorkSpaceBitMapYTV;
        Graphics::TBitmap*  WorkSpaceBitMapMAT;
        Graphics::TBitmap*  WorkSpaceBitMapnmMAT;
        Graphics::TBitmap*  WorkSpaceBitMapXY;
        Graphics::TBitmap*  WorkSpaceBitMapXYZ;
        Graphics::TBitmap*  WorkSpaceBitMapBode;
        Graphics::TBitmap*  WorkSpaceBitMapBlank;
        Graphics::TBitmap*  MatBitMap;
        TRect               BitMapRect;
        TRect               BitMapRect1;
        TRect               BitMapRect2;
        TRect               BitMapRect3;
        TRect               BitMapRect4;
        TRect               BitMapRect5;
        TRect               BitMapRect6;
        TBrush*             SolidBlackBrush;

  __fastcall TForm1(TComponent* Owner);

};


//      SIMFNC

///extern int JDmax;
 extern int ICNT;
 extern int STICKER[25];
 extern long int DELCIRCIND[100],Wyser[100],LHcounter[100];
 extern float *DELMEM;
 extern float *DELMEM0;
 extern int TVALID;
//extern int BODEinSPEC;
 extern float TPASS[25];

 extern double TTEL;
 extern long int JTEL;

 extern bool Sat;

//      BODEFUNC

 extern float  FSTART,FFACT,FEND,FSTARTRND;
 extern double BODEFREQ,BODEPHASE0,INPUT90;
 extern double DENOMAVE0,DENOM0,DENOMAVE90,DENOM90;
 extern double NUMAVE0,NUM0,NUMAVE90,NUM90;
 extern int    BODEinSPEC,BODECNT,REF0,REF00,REF90,DELTCNT0,DELTCNT90,NOofREP;
 extern int    FLOGRATIO,XGRAPH,YGRAPH,PRECYCLES;
 extern double BODETRFINP[3],BODETRFOUTP[3];
 extern double DENOMSIG[3],NUMSIG[3];
 extern double PREVaccGAIN,PREVGAIN,BODEGAIN,BODEGAINAVE,GAIN100;
 extern double PREVaccPHASE,PREVPHASE,BODEPHASE,BODEPHASEAVE,NUMPHASE,DENOMPHASE;
 extern int    GAINFLAG,PHASEFLAG;
 extern float  GAINpoint,PHASEpoint,FREQpoint,FDELT,FfineFACT;

//      DISPLAY
 extern bool DrawXYZ, DXYZG;

 extern float ampl1,ampl2,ampl3,ampl4,
              ampl5,ampl6,ampl7,ampl8,
              ampl9,ampl10,ampl11,ampl12,
              ampl13,ampl14,ampl15,ampl16,
              ampl17,ampl18,ampl19,ampl20,
              ampl21,ampl22,ampl23,ampl24,
              ampl25,ampl26,ampl27;

 extern float XCENTRE, YCENTRE, ZCENTRE,
              XMAX, YMAX, ZMAX;
 extern float PHIxyz, PSIxyz, THExyz;

 extern float XCENTRE1, YCENTRE1,  XMAX1, YMAX1,
              XCENTRE2, YCENTRE2,  XMAX2, YMAX2,
              XCENTRE3, YCENTRE3,  XMAX3, YMAX3,
              XCENTRE4, YCENTRE4,  XMAX4, YMAX4,
              XCENTRE5, YCENTRE5,  XMAX5, YMAX5,
              XCENTRE6, YCENTRE6,  XMAX6, YMAX6,
              XCENTRE7, YCENTRE7,  XMAX7, YMAX7,
              XCENTRE8, YCENTRE8,  XMAX8, YMAX8,
              XCENTRE9, YCENTRE9,  XMAX9, YMAX9,
              XCENTRE10,YCENTRE10, XMAX10,YMAX10,
              XCENTRE11,YCENTRE11, XMAX11,YMAX11;

#define BLUE 	        RGB(0,80,255)
#define SKYBLUE 		RGB(0,128,255)
#define SEABLUE 		RGB(0,170,200)
#define TURQUOISE		RGB(70,150,150)
#define LIGHTGRAY 		RGB(192,192,192)
#define ORANGE 			RGB(255,100,0)
#define LIGHTYELLOW		RGB(255,255,128)
#define KHAKIONE        RGB(177,177,90)
#define DARKGREEN 		RGB(0,128,64)
#define GREEN 	        RGB(50,200,30)
#define LIGHTGREEN      RGB(86,185,13)
#define PGREEN          RGB(159,255,207)
#define DARKRED	        RGB(203,0,85)
#define PINKTHREE 		RGB(255,0,110)
#define MAROON          RGB(200,0,128)
#define PURPLE          RGB(140,0,240)
#define PURPLEFOUR      RGB(128,0,255)
#define LILAC           RGB(200,60,220)
#define SKY             RGB(138,138,255)
#define LIGHTBROWN      RGB(200,100,0)
#define CURRY 	        RGB(242,177,57)
#define SGRAY           RGB(212,208,200)


//---------------------------------------------------------------------------
 extern PACKAGE TForm1 *Form1;
//---------------------------------------------------------------------------

#endif
