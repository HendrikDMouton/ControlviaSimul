//---------------------------------------------------------------------------
#ifndef BatchYTCfg_2017
#define BatchYTCfg_2017
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <Buttons.hpp>
//---------------------------------------------------------------------------
class TBYTCfg : public TForm
{
__published:	// IDE-managed Components
      TGroupBox *GroupBox10;
      TGroupBox *Configuration;
      TLabel *TitleYT;
      TLabel *Tstart;
      TLabel *Tdelt;
      TLabel *Tend;
      TLabel *Tplot;
      TEdit *YTTitle;
      TEdit *YTStart;
      TEdit *YTdelt;
      TEdit *YTend;
      TEdit *YTplot;
      TGroupBox *GroupBox1;
      TLabel *Label1;
      TLabel *Label2;
      TEdit *Signal1;
      TEdit *Signal2;
      TEdit *Signal3;
      TEdit *Scale1;
      TEdit *Scale2;
      TEdit *Scale3;
      TGroupBox *GroupBox2;
      TLabel *Label3;
      TLabel *Label4;
      TEdit *Signal4;
      TEdit *Signal5;
      TEdit *Signal6;
      TEdit *Scale4;
      TEdit *Scale5;
      TEdit *Scale6;
      TGroupBox *GroupBox3;
      TLabel *Label5;
      TLabel *Label6;
      TEdit *Signal7;
      TEdit *Signal8;
      TEdit *Signal9;
      TEdit *Scale7;
      TEdit *Scale8;
      TEdit *Scale9;
      TGroupBox *GroupBox4;
      TLabel *Label7;
      TLabel *Label8;
      TEdit *Signal10;
      TEdit *Signal11;
      TEdit *Signal12;
      TEdit *Scale10;
      TEdit *Scale11;
      TEdit *Scale12;
      TGroupBox *GroupBox5;
      TLabel *Label9;
      TLabel *Label10;
      TEdit *Signal13;
      TEdit *Signal14;
      TEdit *Signal15;
      TEdit *Scale13;
      TEdit *Scale14;
      TEdit *Scale15;
      TGroupBox *GroupBox6;
      TLabel *Label11;
      TLabel *Label12;
      TEdit *Signal16;
      TEdit *Signal17;
      TEdit *Signal18;
      TEdit *Scale16;
      TEdit *Scale17;
      TEdit *Scale18;
      TGroupBox *GroupBox7;
      TLabel *Label13;
      TLabel *Label14;
      TEdit *Signal19;
      TEdit *Signal20;
      TEdit *Signal21;
      TEdit *Scale19;
      TEdit *Scale20;
      TEdit *Scale21;
      TGroupBox *GroupBox8;
      TLabel *Label15;
      TLabel *Label16;
      TEdit *Signal22;
      TEdit *Signal23;
      TEdit *Signal24;
      TEdit *Scale22;
      TEdit *Scale23;
      TEdit *Scale24;
      TGroupBox *GroupBox9;
      TLabel *Label17;
      TLabel *Label18;
      TEdit *Signal25;
      TEdit *Signal26;
      TEdit *Signal27;
      TEdit *Scale25;
      TEdit *Scale26;
      TEdit *Scale27;
      TBitBtn *Done;
      TLabel *Label19;
      TLabel *Label20;
      TLabel *Label21;
      void __fastcall DoneClick(TObject *Sender);
      void __fastcall FormCreate(TObject *Sender);
private:	// User declarations
public:		// User declarations
      __fastcall TBYTCfg(TComponent* Owner);
};

struct BatchYT
{
  char HeaderYT[80];
  float TSTART;
  float TDELT;
  float TEND;
  float TPLOT;
  char Sig1[20];
  char Sig2[20];
  char Sig3[20];
  float ampl1;
  float ampl2;
  float ampl3;
  char Sig4[20];
  char Sig5[20];
  char Sig6[20];
  float ampl4;
  float ampl5;
  float ampl6;
  char Sig7[20];
  char Sig8[20];
  char Sig9[20];
  float ampl7;
  float ampl8;
  float ampl9;
  char Sig10[20];
  char Sig11[20];
  char Sig12[20];
  float ampl10;
  float ampl11;
  float ampl12;
  char Sig13[20];
  char Sig14[20];
  char Sig15[20];
  float ampl13;
  float ampl14;
  float ampl15;
  char Sig16[20];
  char Sig17[20];
  char Sig18[20];
  float ampl16;
  float ampl17;
  float ampl18;
  char Sig19[20];
  char Sig20[20];
  char Sig21[20];
  float ampl19;
  float ampl20;
  float ampl21;
  char Sig22[20];
  char Sig23[20];
  char Sig24[20];
  float ampl22;
  float ampl23;
  float ampl24;
  char Sig25[20];
  char Sig26[20];
  char Sig27[20];
  float ampl25;
  float ampl26;
  float ampl27;
};

//---------------------------------------------------------------------------
extern PACKAGE TBYTCfg *BYTCfg;
//---------------------------------------------------------------------------
#endif
