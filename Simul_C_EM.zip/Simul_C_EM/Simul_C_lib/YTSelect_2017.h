//---------------------------------------------------------------------------
#ifndef YTSelect_2017
#define YTSelect_2017
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <Buttons.hpp>
#include <ComCtrls.hpp>
#include <Dialogs.hpp>
#include "CSPIN.h"
//---------------------------------------------------------------------------
class TYTSelection : public TForm
{
__published:	// IDE-managed Components
        TGroupBox *Configuration;
        TLabel *TitleYT;
        TLabel *Tstart;
        TLabel *Tdelt;
        TLabel *Tend;
        TLabel *Tplot;
        TEdit *YTTitle;
        TEdit *YTStart;
        TEdit *YTdelt;
        TEdit *YTend;
        TEdit *YTplot;
        TGroupBox *GroupBox1;
        TGroupBox *GroupBox2;
        TGroupBox *GroupBox3;
        TGroupBox *GroupBox4;
        TGroupBox *GroupBox5;
        TGroupBox *GroupBox6;
        TGroupBox *GroupBox7;
        TGroupBox *GroupBox8;
        TGroupBox *GroupBox9;
        TGroupBox *GroupBox10;
        TGroupBox *GroupBox11;
        TEdit *Signal1;
        TEdit *Signal2;
        TEdit *Signal3;
        TEdit *Scale1;
        TEdit *Scale2;
        TEdit *Scale3;
        TCheckBox *Graph1;
        TLabel *Label1;
        TLabel *Label2;
      TBitBtn *Done;
        TLabel *Label3;
        TLabel *Label4;
        TEdit *Signal4;
        TEdit *Signal5;
        TEdit *Signal6;
        TEdit *Scale4;
        TEdit *Scale5;
        TEdit *Scale6;
        TCheckBox *Graph2;
        TLabel *Label5;
        TLabel *Label6;
        TEdit *Signal7;
        TEdit *Signal8;
        TEdit *Signal9;
        TEdit *Scale7;
        TEdit *Scale8;
        TEdit *Scale9;
        TCheckBox *Graph3;
        TLabel *Label7;
        TLabel *Label8;
        TLabel *Label9;
        TLabel *Label10;
        TLabel *Label11;
        TLabel *Label12;
        TLabel *Label13;
        TLabel *Label14;
        TLabel *Label15;
        TLabel *Label16;
        TLabel *Label17;
        TLabel *Label18;
        TCheckBox *Graph4;
        TCheckBox *Graph5;
        TCheckBox *Graph6;
        TCheckBox *Graph7;
        TCheckBox *Graph8;
        TCheckBox *Graph9;
        TEdit *Signal10;
        TEdit *Signal11;
        TEdit *Signal12;
        TEdit *Scale10;
        TEdit *Scale11;
        TEdit *Scale12;
        TEdit *Signal13;
        TEdit *Signal14;
        TEdit *Signal15;
        TEdit *Scale13;
        TEdit *Scale14;
        TEdit *Scale15;
        TEdit *Signal16;
        TEdit *Signal17;
        TEdit *Signal18;
        TEdit *Scale16;
        TEdit *Scale17;
        TEdit *Scale18;
        TEdit *Signal19;
        TEdit *Signal20;
        TEdit *Signal21;
        TEdit *Scale19;
        TEdit *Scale20;
        TEdit *Scale21;
        TEdit *Signal22;
        TEdit *Signal23;
        TEdit *Signal24;
        TEdit *Scale22;
        TEdit *Scale23;
        TEdit *Scale24;
        TEdit *Signal25;
        TEdit *Signal26;
        TEdit *Signal27;
        TEdit *Scale25;
        TEdit *Scale26;
        TEdit *Scale27;
        TBitBtn *ALLYTG;
        TBitBtn *ALLYTV;
        TCheckBox *YTVSig1;
        TCheckBox *YTVSig2;
        TCheckBox *YTVSig3;
        TCheckBox *YTVSig4;
        TCheckBox *YTVSig5;
        TCheckBox *YTVSig6;
        TCheckBox *YTVSig7;
        TCheckBox *YTVSig8;
        TCheckBox *YTVSig9;
        TCheckBox *YTVSig10;
        TCheckBox *TextFile;
        TEdit *YTVSTime;
        TLabel *Label22;
        TLabel *Label19;
        TLabel *Label20;
        TLabel *Label21;
        TLabel *Label23;
        TLabel *Label24;
        TLabel *Label25;
        TLabel *Label26;
        TLabel *Label27;
        TLabel *Label28;
        TLabel *Label29;
        TLabel *Label30;
        TCheckBox *XYOnMain;
        TLabel *Label31;
        TBitBtn *OpenSavedSetup;
        TBitBtn *SaveNewSetup;
        TCheckBox *XYGr;
        TCheckBox *XYZGr;
      TGroupBox *GroupBox12;
      TLabel *Label32;
      TLabel *Label33;
      TLabel *Label34;
      TLabel *Label35;
      TLabel *Label36;
      TLabel *Label37;
      TLabel *Label38;
      TLabel *Label39;
      TLabel *Label40;
      TLabel *Label43;
      TCheckBox *MatVal1;
      TCheckBox *MatVal2;
      TCheckBox *MatVal3;
      TCheckBox *MatVal4;
      TCheckBox *MatVal5;
      TCheckBox *MatVal6;
      TCheckBox *MatVal7;
      TCheckBox *MatVal8;
      TCheckBox *MatVal9;
      TEdit *MatSTime;
      TBitBtn *ALLMATV;
      TCheckBox *TextFileM;
      TLabel *Label41;
      TLabel *Label42;
        TCheckBox *VisMat;
        TGroupBox *GroupBox13;
        TCheckBox *ViewNM;
        TCheckBox *TextFileNM;
        void __fastcall DoneClick(TObject *Sender);
        void __fastcall Graph1Click(TObject *Sender);
        void __fastcall Graph2Click(TObject *Sender);
        void __fastcall Graph3Click(TObject *Sender);
        void __fastcall Graph4Click(TObject *Sender);
        void __fastcall Graph5Click(TObject *Sender);
        void __fastcall Graph6Click(TObject *Sender);
        void __fastcall Graph7Click(TObject *Sender);
        void __fastcall Graph8Click(TObject *Sender);
        void __fastcall Graph9Click(TObject *Sender);
        void __fastcall FormClose(TObject *Sender, TCloseAction &Action);
        void __fastcall ALLYTGClick(TObject *Sender);
        void __fastcall ALLYTVClick(TObject *Sender);
        void __fastcall YTVSig1Click(TObject *Sender);
        void __fastcall YTVSig2Click(TObject *Sender);
        void __fastcall YTVSig3Click(TObject *Sender);
        void __fastcall YTVSig4Click(TObject *Sender);
        void __fastcall YTVSig5Click(TObject *Sender);
        void __fastcall YTVSig6Click(TObject *Sender);
        void __fastcall YTVSig7Click(TObject *Sender);
        void __fastcall YTVSig8Click(TObject *Sender);
        void __fastcall YTVSig9Click(TObject *Sender);
        void __fastcall YTVSig10Click(TObject *Sender);
        void __fastcall XYOnMainClick(TObject *Sender);
        void __fastcall OpenSavedSetupClick(TObject *Sender);
        void __fastcall SaveNewSetupClick(TObject *Sender);
        void __fastcall XYGrClick(TObject *Sender);
        void __fastcall XYZGrClick(TObject *Sender);
      void __fastcall ALLMATVClick(TObject *Sender);
      void __fastcall MatVal1Click(TObject *Sender);
      void __fastcall MatVal2Click(TObject *Sender);
      void __fastcall MatVal3Click(TObject *Sender);
      void __fastcall MatVal4Click(TObject *Sender);
      void __fastcall MatVal5Click(TObject *Sender);
      void __fastcall MatVal6Click(TObject *Sender);
      void __fastcall MatVal7Click(TObject *Sender);
      void __fastcall MatVal8Click(TObject *Sender);
      void __fastcall MatVal9Click(TObject *Sender);
        void __fastcall ViewNMClick(TObject *Sender);
private:	// User declarations
public:		// User declarations
        __fastcall TYTSelection(TComponent* Owner);
};
//--- VARIABLES -------------------------------------------------------------

 extern int ChoiceBorSim;
 extern int NoOfGraphs;
 extern int YTValues;
 extern int MatValues;
 //extern double Tsimulc;
 extern float ampl1,ampl2,ampl3,ampl4,
              ampl5,ampl6,ampl7,ampl8,
              ampl9,ampl10,ampl11,ampl12,
              ampl13,ampl14,ampl15,ampl16,
              ampl17,ampl18,ampl19,ampl20,
              ampl21,ampl22,ampl23,ampl24,
              ampl25,ampl26,ampl27;
 //extern float TSTART, TDELT, TEND, TPLOT, STARTYT, STARTMAT;
 extern char HeaderYT[80];
 extern char Sig1[20],Sig2[20],Sig3[20],Sig4[20],
             Sig5[20],Sig6[20],Sig7[20],Sig8[20],
             Sig9[20],Sig10[20],Sig11[20],Sig12[20],
             Sig13[20],Sig14[20],Sig15[20],Sig16[20],
             Sig17[20],Sig18[20],Sig19[20],Sig20[20],
             Sig21[20],Sig22[20],Sig23[20],Sig24[20],
             Sig25[20],Sig26[20],Sig27[20];

//---------------------------------------------------------------------------
extern PACKAGE TYTSelection *YTSelection;
//---------------------------------------------------------------------------
#endif
