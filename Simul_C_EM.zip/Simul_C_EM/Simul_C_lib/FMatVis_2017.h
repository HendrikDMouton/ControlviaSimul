//---------------------------------------------------------------------------
#ifndef FMatVis_2017
#define FMatVis_2017
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <ExtCtrls.hpp>
#include <Buttons.hpp>
#include <Dialogs.hpp>
//---------------------------------------------------------------------------
class TMatVis : public TForm
{
__published:	// IDE-managed Components
        TPaintBox *PaintBox;
        TLabel *X0;
        TLabel *Y0;
        TLabel *MaxCols;
        TLabel *MaxRows;
        TBitBtn *CloseButton;
        TLabel *Heading;
        TButton *PrintM;
        TPrintDialog *PrintDialog;
        TBitBtn *SaveBitmap;
        TLabel *TimeLabel;
        void __fastcall CloseButtonClick(TObject *Sender);
        void __fastcall PrintMClick(TObject *Sender);
        void __fastcall SaveBitmapClick(TObject *Sender);
        void __fastcall FormCreate(TObject *Sender);
private:	// User declarations
public:		// User declarations
        __fastcall TMatVis(TComponent* Owner);
        Graphics::TBitmap*  MatBitMap;
};

//---------------------------------------------------------------------------
extern PACKAGE TMatVis *MatVis;
//---------------------------------------------------------------------------

#endif
