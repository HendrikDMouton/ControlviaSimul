//---------------------------------------------------------------------------
#ifndef BatchXYZSel_2017
#define BatchXYZSel_2017
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <Buttons.hpp>
#include <Dialogs.hpp>
//---------------------------------------------------------------------------
class TBXYZSel : public TForm
{
__published:	// IDE-managed Components
      TListBox *ListBox1;
      TBitBtn *Accept;
      TBitBtn *Cancel;
      TSaveDialog *SaveDialogBXYZ;
      TOpenDialog *OpenDialogCFGBXYZ;
        TLabel *Label1;
      void __fastcall FormDestroy(TObject *Sender);
      void __fastcall FormCreate(TObject *Sender);
      void __fastcall CancelClick(TObject *Sender);
      void __fastcall ListBox1MouseUp(TObject *Sender, TMouseButton Button,
          TShiftState Shift, int X, int Y);
      void __fastcall AcceptClick(TObject *Sender);
private:	// User declarations
public:		// User declarations
      __fastcall TBXYZSel(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TBXYZSel *BXYZSel;
//---------------------------------------------------------------------------
#endif
