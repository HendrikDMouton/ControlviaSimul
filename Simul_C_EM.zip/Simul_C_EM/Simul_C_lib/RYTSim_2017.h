//---------------------------------------------------------------------------
#ifndef RYTSim_2017
#define RYTSim_2017
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <Buttons.hpp>
//---------------------------------------------------------------------------
class TRYTSimulation : public TForm
{
__published:	// IDE-managed Components
        TBitBtn *RYTSimDone;
        TEdit *NoofRepeats;
        TLabel *LNoOfRepeats;
        TLabel *LNoOfGraphs;
        TLabel *Label1;
        TLabel *Label2;
        TEdit *NoofGraphs;
        TBitBtn *RCancel;
        TCheckBox *RXYGraph;
        TCheckBox *RXYZGraph;
        TCheckBox *RYTValues;
        TEdit *RNoofYTV;
        TEdit *RYTVSTime;
        TLabel *Label3;
        TLabel *RNoYTV;
      TBitBtn *CreateNewYTSetup;
      TBitBtn *CreateNewXYSetup;
      TBitBtn *CreateNewXYZSetup;
      TBitBtn *EditExistingYTSetup;
      TBitBtn *EditExistingXYSetup;
      TBitBtn *EditExistingXYZSetup;
        TLabel *Label4;
        TLabel *Label5;
        void __fastcall RYTSimDoneClick(TObject *Sender);
        void __fastcall RCancelClick(TObject *Sender);
      void __fastcall FormDestroy(TObject *Sender);
      void __fastcall CreateNewYTSetupClick(TObject *Sender);
      void __fastcall CreateNewXYSetupClick(TObject *Sender);
      void __fastcall FormCreate(TObject *Sender);
      void __fastcall CreateNewXYZSetupClick(TObject *Sender);
      void __fastcall RXYGraphClick(TObject *Sender);
      void __fastcall RXYZGraphClick(TObject *Sender);
      void __fastcall EditExistingYTSetupClick(TObject *Sender);
      void __fastcall EditExistingXYSetupClick(TObject *Sender);
      void __fastcall EditExistingXYZSetupClick(TObject *Sender);
private:	// User declarations
public:		// User declarations
        __fastcall TRYTSimulation(TComponent* Owner);
};
//---------------------------------------------------------------------------
//extern bool RXY,RXYZ,RYTV;
//extern int NoOfRepeats;
//extern float STARTYT;
//---------------------------------------------------------------------------
extern PACKAGE TRYTSimulation *RYTSimulation;
//---------------------------------------------------------------------------
#endif
