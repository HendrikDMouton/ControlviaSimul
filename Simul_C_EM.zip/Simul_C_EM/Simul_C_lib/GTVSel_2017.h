//---------------------------------------------------------------------------

#ifndef GTVSel_ADAMS_2017H
#define GTVSel_ADAMS_2017H
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <Buttons.hpp>
//---------------------------------------------------------------------------
class TFGTVSel : public TForm
{
__published:	// IDE-managed Components
      TListBox *ListBox1;
      TBitBtn *OK;
      TBitBtn *Cancel;
      void __fastcall OKClick(TObject *Sender);
      void __fastcall CancelClick(TObject *Sender);
      void __fastcall FormCreate(TObject *Sender);
      void __fastcall ListBox1MouseUp(TObject *Sender, TMouseButton Button,
          TShiftState Shift, int X, int Y);
      void __fastcall FormDestroy(TObject *Sender);
private:	// User declarations
public:		// User declarations
      __fastcall TFGTVSel(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TFGTVSel *FGTVSel;
//---------------------------------------------------------------------------
#endif
