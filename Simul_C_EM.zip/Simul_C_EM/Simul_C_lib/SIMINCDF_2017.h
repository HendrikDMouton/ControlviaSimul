/*****               SIMINCDF.H               *****/

#ifndef _SIM_INC_DEF
#define _SIM_INC_DEF

//#ifndef SIMULINK
#include <windows.h>
#include <commdlg.h>
#include <alloc.h>
//#endif

#include <string.h>
#include <stdio.h>
#include <math.h>
#include <stdlib.h>

#define PI 3.141592654
#define pi 3.141592654

#endif //include protection
