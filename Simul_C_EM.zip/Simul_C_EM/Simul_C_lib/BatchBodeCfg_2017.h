//---------------------------------------------------------------------------

#ifndef BatchBodeCfg_2017
#define BatchBodeCfg_2017
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <Buttons.hpp>
//---------------------------------------------------------------------------
class TBBodeCfg : public TForm
{
__published:	// IDE-managed Components
      TLabel *Label1;
      TLabel *Label2;
      TLabel *Label3;
      TLabel *Label4;
      TLabel *Label5;
      TLabel *Label6;
      TLabel *Label7;
      TLabel *Label8;
      TLabel *Label9;
      TLabel *Label10;
      TBitBtn *BSetupDone;
      TEdit *BodeTitle;
      TEdit *FStart;
      TEdit *Ffact;
      TEdit *FEnd;
      TEdit *Gpoint;
      TEdit *Ppoint;
      TEdit *Fpoint;
      TEdit *Fdelt;
      TEdit *Ffine;
      TEdit *BTDelt;
      TLabel *Label46;
      TLabel *Label47;
      TLabel *Label48;
      TLabel *Label49;
      void __fastcall FormCreate(TObject *Sender);
      void __fastcall BSetupDoneClick(TObject *Sender);
private:	// User declarations
public:		// User declarations
      __fastcall TBBodeCfg(TComponent* Owner);
};
struct BatchBode
{
  char HeaderBode[80];
  float FSTART;
  float FFACT;
  float FEND;
  float GAINpoint;
  float PHASEpoint;
  float FREQpoint;
  float FDELT;
  float FfineFACT;
  float TDELT;
};

//---------------------------------------------------------------------------
extern PACKAGE TBBodeCfg *BBodeCfg;
//---------------------------------------------------------------------------
#endif
