//---------------------------------------------------------------------------

#ifndef BatchXYZCfg_2017
#define BatchXYZCfg_2017
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <Buttons.hpp>
#include <ComCtrls.hpp>
#include <ExtCtrls.hpp>
//---------------------------------------------------------------------------
class TBXYZCfg : public TForm
{
__published:	// IDE-managed Components
      TLabel *Label1;
      TLabel *Label2;
      TLabel *Label3;
      TLabel *Label4;
      TLabel *Label5;
      TLabel *Label6;
      TLabel *Label7;
      TLabel *Label8;
      TLabel *Label9;
      TLabel *Label10;
      TImage *Image1;
      TLabel *Label11;
      TLabel *Label12;
      TLabel *Label13;
      TEdit *XC;
      TEdit *YC;
      TEdit *ZC;
      TBitBtn *BXYZDone;
      TEdit *XM;
      TEdit *YM;
      TEdit *ZM;
      TTrackBar *TrackBar1;
      TTrackBar *TrackBar2;
      TTrackBar *TrackBar3;
      TLabel *Label15;
      TLabel *Label16;
      TLabel *Label17;
      TLabel *Label14;
      void __fastcall BXYZDoneClick(TObject *Sender);
      void __fastcall FormCreate(TObject *Sender);
      void __fastcall FormDestroy(TObject *Sender);
      void __fastcall TrackBar1Change(TObject *Sender);
      void __fastcall TrackBar2Change(TObject *Sender);
      void __fastcall TrackBar3Change(TObject *Sender);
private:	// User declarations
        void UpdateLabels () ;
public:		// User declarations
        Graphics::TBitmap*  RotateAxis;
        TRect               RotateRect;
        TBrush*             SolidBlackBrush;
      __fastcall TBXYZCfg(TComponent* Owner);
};

struct BatchXYZ
{
  float XCENTRE;
  float YCENTRE;
  float ZCENTRE;
  float XMAX;
  float YMAX;
  float ZMAX;
  float PHIxyz;
  float PSIxyz;
  float THExyz;
};

//---------------------------------------------------------------------------
extern PACKAGE TBXYZCfg *BXYZCfg;
//---------------------------------------------------------------------------
#endif
