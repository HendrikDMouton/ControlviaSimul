//---------------------------------------------------------------------------
#ifndef BodeSelect_2017
#define BodeSelect_2017
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <Buttons.hpp>
//---------------------------------------------------------------------------
class TBodeSelection : public TForm
{
__published:	// IDE-managed Components
        TBitBtn *BSetupDone;
        TLabel *Label1;
        TLabel *Label2;
        TLabel *Label3;
        TLabel *Label4;
        TLabel *Label5;
        TLabel *Label6;
        TLabel *Label7;
        TLabel *Label8;
        TLabel *Label9;
        TLabel *Label10;
        TEdit *FStart;
        TEdit *BodeTitle;
        TEdit *Ffact;
        TEdit *FEnd;
        TEdit *Gpoint;
        TEdit *Ppoint;
        TEdit *Fpoint;
        TEdit *Fdelt;
        TEdit *Ffine;
        TEdit *BTDelt;
        TBitBtn *OpenSavedSetupB;
        TBitBtn *SaveNewSetupB;
        void __fastcall BSetupDoneClick(TObject *Sender);
        void __fastcall FormClose(TObject *Sender, TCloseAction &Action);
        void __fastcall OpenSavedSetupBClick(TObject *Sender);
        void __fastcall SaveNewSetupBClick(TObject *Sender);
private:	// User declarations
public:		// User declarations
        __fastcall TBodeSelection(TComponent* Owner);
};
//---------------------------------------------------------------------------
//--- VARIABLES -------------------------------------------------------------

 //extern float  TDELT;

 extern char   HeaderBode[80];
 extern float  FSTART;
 extern float  FFACT;
 extern float  FEND;
 extern float  GAINpoint;
 extern float  PHASEpoint;
 extern float  FREQpoint;
 extern float  FDELT;
 extern float  FfineFACT;
 extern float  FSTART,FFACT,FEND,FSTARTRND,FENDRND;
 extern int    FLOGRATIO,PRECYCLES;
 extern float  GAINpoint,PHASEpoint,FREQpoint,FDELT,FfineFACT;
 extern int    BODECNT;
 extern int    GAINFLAG,PHASEFLAG;
 extern double BODEFREQ;
 extern double PREVaccGAIN,PREVGAIN,BODEGAIN,GAIN100,
	       PREVaccPHASE,PREVPHASE,BODEPHASE;


//---------------------------------------------------------------------------
extern PACKAGE TBodeSelection *BodeSelection;
//---------------------------------------------------------------------------
#endif
