//---------------------------------------------------------------------------

#ifndef GTVGraph_2017H
#define GTVGraph_2017H
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <Chart.hpp>
#include <ExtCtrls.hpp>
#include <Series.hpp>
#include <TeEngine.hpp>
#include <TeeProcs.hpp>
#include <Buttons.hpp>
#include <Dialogs.hpp>
//---------------------------------------------------------------------------
class TGTVChart : public TForm
{
__published:	// IDE-managed Components
      TChart *GTVChart;
      TLabel *Label1;
      TLineSeries *Series1;
      TBitBtn *Cancel;
      TButton *PrintL;
      TButton *PrintP;
      TPrintDialog *PrintDialog;
      TSaveDialog *SaveDialog1;
      TButton *SaveGraph;
      void __fastcall GTVChartMouseMove(TObject *Sender, TShiftState Shift,
          int X, int Y);
      void __fastcall CancelClick(TObject *Sender);
      void __fastcall PrintLClick(TObject *Sender);
      void __fastcall PrintPClick(TObject *Sender);
      void __fastcall SaveGraphClick(TObject *Sender);
private:	// User declarations
public:		// User declarations
      __fastcall TGTVChart(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TGTVChart *GTVChart;
//---------------------------------------------------------------------------
#endif
