//---------------------------------------------------------------------------
#ifndef XYConfig_2017
#define XYConfig_2017
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <Buttons.hpp>
//---------------------------------------------------------------------------
class TXYConfigScr : public TForm
{
__published:	// IDE-managed Components
        TEdit *XC1;
        TLabel *Label1;
        TLabel *Label2;
        TEdit *XC2;
        TEdit *XC3;
        TEdit *XC4;
        TEdit *XC5;
        TEdit *XC6;
        TEdit *XC7;
        TEdit *XC8;
        TEdit *XC9;
        TEdit *XC10;
        TEdit *XC11;
        TLabel *Label3;
        TLabel *Label4;
        TLabel *Label5;
        TLabel *Label6;
        TLabel *Label7;
        TLabel *Label8;
        TLabel *Label9;
        TLabel *Label10;
        TLabel *Label11;
        TLabel *Label12;
        TLabel *Label13;
        TLabel *Label14;
        TLabel *Label15;
        TLabel *Label16;
        TLabel *Label17;
        TLabel *Label18;
        TLabel *Label19;
        TLabel *Label20;
        TLabel *Label21;
        TLabel *Label22;
        TEdit *YC1;
        TEdit *YC2;
        TEdit *YC3;
        TEdit *YC4;
        TEdit *YC5;
        TEdit *YC6;
        TEdit *YC7;
        TEdit *YC8;
        TEdit *YC9;
        TEdit *YC10;
        TEdit *YC11;
        TLabel *Label23;
        TLabel *Label24;
        TLabel *Label25;
        TLabel *Label26;
        TLabel *Label27;
        TLabel *Label28;
        TLabel *Label29;
        TLabel *Label30;
        TLabel *Label31;
        TLabel *Label32;
        TLabel *Label33;
        TEdit *XM1;
        TEdit *XM2;
        TEdit *XM3;
        TEdit *XM4;
        TEdit *XM5;
        TEdit *XM6;
        TEdit *XM7;
        TEdit *XM8;
        TEdit *XM9;
        TEdit *XM10;
        TEdit *XM11;
        TLabel *Label34;
        TLabel *Label35;
        TLabel *Label36;
        TLabel *Label37;
        TLabel *Label38;
        TLabel *Label39;
        TLabel *Label40;
        TLabel *Label41;
        TLabel *Label42;
        TLabel *Label43;
        TLabel *Label44;
        TEdit *YM1;
        TEdit *YM2;
        TEdit *YM3;
        TEdit *YM4;
        TEdit *YM5;
        TEdit *YM6;
        TEdit *YM7;
        TEdit *YM8;
        TEdit *YM9;
        TEdit *YM10;
        TEdit *YM11;
        TBitBtn *XYOSS;
        TBitBtn *XYSNS;
        TBitBtn *XYDONE;
        TLabel *Label45;
        void __fastcall XYDONEClick(TObject *Sender);
        void __fastcall XYOSSClick(TObject *Sender);
        void __fastcall XYSNSClick(TObject *Sender);
private:	// User declarations
public:		// User declarations
        __fastcall TXYConfigScr(TComponent* Owner);
};

//---------------------------------------------------------------------------
extern PACKAGE TXYConfigScr *XYConfigScr;
//---------------------------------------------------------------------------

#endif
