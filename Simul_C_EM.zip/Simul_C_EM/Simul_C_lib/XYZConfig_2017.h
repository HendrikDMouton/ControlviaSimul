//---------------------------------------------------------------------------
#ifndef XYZConfig_2017
#define XYZConfig_2017
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <Buttons.hpp>
#include <ComCtrls.hpp>
#include <ExtCtrls.hpp>
//---------------------------------------------------------------------------
class TXYZConfigScr : public TForm
{
__published:	// IDE-managed Components
        TLabel *Label1;
        TLabel *Label2;
        TLabel *Label3;
        TLabel *Label4;
        TLabel *Label5;
        TLabel *Label6;
        TLabel *Label7;
        TEdit *XC;
        TEdit *YC;
        TEdit *ZC;
        TBitBtn *XYZOSS;
        TBitBtn *XYZSNS;
        TBitBtn *XYZDone;
        TLabel *Label8;
        TLabel *Label9;
        TLabel *Label10;
        TEdit *XM;
        TEdit *YM;
        TEdit *ZM;
        TImage *Image1;
        TTrackBar *TrackBar1;
        TTrackBar *TrackBar2;
        TTrackBar *TrackBar3;
        TLabel *Label11;
        TLabel *Label12;
        TLabel *Label13;
        void __fastcall XYZDoneClick(TObject *Sender);
        void __fastcall XYZOSSClick(TObject *Sender);
        void __fastcall XYZSNSClick(TObject *Sender);
        void __fastcall FormCreate(TObject *Sender);
        void __fastcall TrackBar1Change(TObject *Sender);
        void __fastcall TrackBar2Change(TObject *Sender);
        void __fastcall TrackBar3Change(TObject *Sender);
        void __fastcall FormDestroy(TObject *Sender);
private:	// User declarations
        void UpdateLabels () ;
public:		// User declarations
        Graphics::TBitmap*  RotateAxis;
        TRect               RotateRect;
        TBrush*             SolidBlackBrush;
        __fastcall TXYZConfigScr(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TXYZConfigScr *XYZConfigScr;
//---------------------------------------------------------------------------
#endif
