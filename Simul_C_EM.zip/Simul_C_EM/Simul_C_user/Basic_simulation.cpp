
// Beware: Lines marked compulsory1-20 must be there for this simulation software 
// to function properly !!  
// The user can change the other lines according to his/her simulation and must 
// then save the file under its own name. 

/*****************************************************************************/
/**********                     Basic simulation                    **********/
/*****************************************************************************/

#pragma hdrstop								        							// compulsory1
#include "SIMPROTO_2017.H"                                                      // compulsory2
#include "SIMINCDF_2017.H"                                                      // compulsory3
#include "SIMULDCL_2017.H"                                                      // compulsory4
#include "Graphics.h"                                                           // compulsory5

/*****************************************************************************/
/**********             PARAMETERS, CONSTANTS & VARIABLES           **********/
/*****************************************************************************/

const double WG	        =	2.0*PI*100.0;  			// rad/s
const double ZG	        =	0.7;

const double Iyp        =	1.00e-3;  	        	// kg.m2

const double Kfrcoef    = 	1.0e-4;   				// Nm/(rad/s)

const double KP	        =	21.0*80.0;

const double p          =  	1.0/(2.0*pi*6.0); 		// s

const double TAU1       =  	1.0/(2.0*pi*30.0); 		// s
const double TAU2       =	1.0/(2.0*pi*300.0);		// s
const double TAU3       =	1.0/(2.0*pi*70.0);		// s
const double TAU4       =	1.0/(2.0*pi*500.0);		// s

/*****************************************************************************/
/**********                     MAIN PROGRAM                        **********/
/*****************************************************************************/

#pragma argsused  // pragma suppresses "calling argument not used" warnings		// compulsory6
BOOL WINAPI DllEntryPoint(						        						// compulsory7
HINSTANCE hinst, DWORD reason, LPVOID reserved)				        			// compulsory8
{									        									// compulsory9
return TRUE;								        							// compulsory10
}									        									// compulsory11
__declspec(dllexport)							        						// compulsory12

void SIMUL_C(void)                                                              // compulsory13
{                                                                               // compulsory14
/**********                     INITIALIZATION 	                    **********/

//  SETSIGNAL(0.05,V4);

/*****************************************************************************/
/**********                     PROGRAM LOOP                        **********/
/*****************************************************************************/

  for (Tsimulc=0.1*TDELT; Tsimulc<TEND; Tsimulc=Tsimulc+TDELT)                  // compulsory15
  {                                                                             // compulsory16
    JMsimulc=-1; JSsimulc=-1; JDsimulc=-1; JDLHsimulc=-1;                       // compulsory17
 
    SINE(0.1,0.1,0.0,15.0,V1);
//	SINE(0.1,0.5,0.0,60.0,V17);
	  
//      BODECALC(V1,0.14,V3,V2);
//      BODECALC(V1,0.05,V1,V2);
//      BODECALC(V1,0.1,V1,V117);

    DIFF(V1,V2,V3);                             // V3 = V1-V2
    LEADLAG(V3,p,1.0,1.0,0.0,V4);               // V4 = V3*(p.s+1)/s
    LEADLAG(V4,TAU3,1.0,TAU4,1.0,V10);          // V10 = V4*(TAU3.s+1)/(TAU4.s+1)
    GAIN(V10,KP,V11);                           // V11 = V10*KP

    DIFF(V11,V12,V13);

    DIFF(V13,V14,V15);
    INTEGR(V15,1.0/Iyp,V16);                    // V16 = V15*1/(Iyp.s)
    DIFF(V16,V17,V18);
    GAIN(V18,Kfrcoef,V14);

    INTEGR(V18,1.0,V20);
	
    GAUSSNOISE(0.6,0.0,0.01,V116);
    // V116 = Gaussian noise, starting at 0.6 s, average 0, and RMS noise of 0.01

    RMS(V116,0.7,V118);
    // V118 = RMS of V116, start to calculate it at 0.7 s

    SUM(V20,V116,V117);                         // V117 = V20+V116

    BIQUAD(V117,0.0,0.0,WG*WG,1.0,2.0*ZG*WG,WG*WG,V21);
    // V21 = V117*(WG^2/(s^2+2.ZG.WG.s+WG^2)

    LEADLAG(V21,TAU1,1.0,TAU2,1.0,V2);

/**********                  GRAPHING SECTION                       **********/

    YTDRAW(	V1,   	V20,  	V17,                                          	
			V11, 	V3,   	V2,
			V16,  	V19,  	V0,
			V116, 	V118,  	V0,
			V128,  	V129,  	V0,
			V62, 	V0,   	V0,
			V64,  	V0,  	V0,
			V153, 	V0,   	V0,
			V103, 	V104,	V0 );

    XYDRAW(	V1, 	V20,
			V117, 	V21,
			V21, 	V2,
			V0, 	V0,
			V0, 	V0,
			V0, 	V0,
			V0, 	V0,
			V0, 	V0,
			V0, 	V0,
			V0, 	V0,
			V0, 	V0 	);
	
/*****************************************************************************/

  }	// End of PROGRAM LOOP                                     	        		// compulsory18
}	// End of void SIMUL_C(void)  					        					// compulsory19

#pragma package(smart_init)						        						// compulsory20

/*****************************************************************************/
/**********                    END OF PROGRAM                       **********/
/*****************************************************************************/

